import React from 'react';
import ShippingTest from '../../components/ShippingTest/ShippingTest';

const ShippingDemo = () => {
  return (
    <div>
      <ShippingTest />
    </div>
  );
};

export default ShippingDemo;
